#Finding averages of each year based on clean data
#inflation
rel_freq('./data/google/inflation/clean_inf_Canada.csv')
rel_freq('./data/google/inflation/clean_inf_South_Africa.csv')
rel_freq('./data/google/inflation/clean_inf_NZ.csv')
rel_freq('./data/google/inflationclean_inf_US.csv')
#unemployment
rel_freq('./data/google/unemployment/clean_unemp_Canada.csv')
rel_freq('./data/google/unemployment/clean_unemp_South_Africa.csv')
rel_freq('./data/google/unemployment/clean_unemp_NZ.csv')
rel_freq('./data/google/unemployment/clean_unemp_US.csv')